#!/usr/bin/env ruby

require 'amb'

A = Amb.new

begin
 pairs = { 0 => 0, 1 => 1, 2 => 5, 5 => 2, 8 => 8 }
 date = []
 date[0] = A.choose(*pairs.keys)
 date[1] = A.choose(*pairs.keys)
 date[2] = A.choose(*pairs.keys)
 date[3] = A.choose(*pairs.keys)
 date[4] = A.choose(*pairs.keys)
 date[5] = A.choose(*pairs.keys)
 date[6] = A.choose(*pairs.keys)
 date[7] = A.choose(*pairs.keys)
 year = "#{date[4]}#{date[5]}#{date[6]}#{date[7]}".to_i 
 month = "#{date[2]}#{date[3]}".to_i 
 day = "#{date[0]}#{date[1]}".to_i

 last_day = 28

 A.assert date[4] != 0
 A.assert pairs[date[0]] == date[7]
 A.assert pairs[date[1]] == date[6]
 A.assert pairs[date[2]] == date[5]
 A.assert pairs[date[3]] == date[4]
 A.assert 0 < month
 A.assert month <= 12
 A.assert 0 < day
 A.assert day <= last_day

 print "#{date[0]}#{date[1]} #{date[2]}#{date[3]} #{year}\n"
 A.failure

 rescue Amb::ExhaustedError
end
