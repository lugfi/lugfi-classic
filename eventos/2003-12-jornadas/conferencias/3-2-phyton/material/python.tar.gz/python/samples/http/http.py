#!/usr/bin/python
import httplib
import gtk
import gnome.ui
import gtk.glade
import gobject
import string
import sys

class HTTPDemo:
	def __init__(self):
		# Cargo la ventana desde el XML
		self.wTree = gtk.glade.XML ("proyecto1.glade", "ventana")
		# Conecto las signals con los handlers
		dic = { "on_btn_salir_clicked": gtk.mainquit,
			"on_lista_row_activated": self.load_image}
		self.wTree.signal_autoconnect(dic)

		lista = self.wTree.get_widget ("lista")
		self.model = gtk.TreeStore( gobject.TYPE_PYOBJECT, gobject.TYPE_STRING )
		lista.set_model(self.model);
		renderer = gtk.CellRendererText ()
		column = gtk.TreeViewColumn ("Imagen", renderer, text=1)
		lista.append_column (column)

		# Leo los archivos desde la web
		self.conn = httplib.HTTPConnection("localhost")
		self.conn.request("GET", "/imagenes.desc")
		resp = self.conn.getresponse()
		if (resp.status == 200):
			# si la respuesta en correcta, leo el contenido
			body = resp.read()
			# separo el texto en un array
			arr = string.split(body, "\n")
			# cargo el array en una lista
			for i in range(len(arr)):
				dato = { "name": arr.pop(0), "otro": "nada" }
				iter = self.model.insert_before(None, None)
				self.model.set_value (iter, 0, dato)
				self.model.set_value (iter, 1, dato["name"])

			#cargo una imagen
			self.conn.request("GET", "/imagen1.png")
			resp_img = self.conn.getresponse()
			if (resp_img.status == 200):
				f = open("tmp.png", "w");
				f.write( resp_img.read() );
				f.close();
				imagen = self.wTree.get_widget ("imagen")
				imagen.set_from_file("tmp.png")
			else:
				print "Todo mal"

	def load_image(self,widget,a,b):
		lista = self.wTree.get_widget("lista")
		store, iter = lista.get_selection().get_selected()
		filename = "/"+self.model.get_value(iter, 0)["name"]
		filename.replace(" ", "%20");
		conn = httplib.HTTPConnection("localhost")
		conn.request("GET", filename)
		resp_img = conn.getresponse()
		if (resp_img.status == 200):
			f = open("tmp.png", "w");
			f.write( resp_img.read() );
			f.close();
			imagen = self.wTree.get_widget ("imagen")
			imagen.set_from_file("tmp.png")
		else:
			print "Todo mal"

app = HTTPDemo()
gtk.mainloop ()

