N=10000;
X=rand(1,N);
for i = 1:N
	if X(i)<.75
		X(i) = 1;
	else
		X(i) = 2;
	endif
endfor
Y=randn(1,N)*sqrt(0.5)+X;
H=hist(Y,linspace(-2,6,100),1)

