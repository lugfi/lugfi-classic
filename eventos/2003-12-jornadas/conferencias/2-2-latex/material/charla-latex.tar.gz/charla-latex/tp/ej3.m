N=1000;
u=randn(1,N);
h10=ones(1,10)/10;
h20=ones(1,20)/20;
y10=filter(h10,1,u);
y20=filter(h20,1,u);

%Para graficar:
%subplot(3,1,1)
%plot(u)
%subplot(3,1,2)
%plot(y10)
%subplot(3,1,3)
%plot(y20)

%punto 1
clc
m10=mean(y10)
m20=mean(y20)

v10=var(y10)
v20=var(y20)

%punto 2
X=linspace(-1.5,1.5,100);
H10=hist(y10,X,1);
H20=hist(y20,X,1);
%data=

%punto 3
Ry10=xcorr(y10,'biased');
%subplot(2,2,1)
%plot(Ry10s)
%Ry10i=xcorr(y10,'unbiased');
%subplot(2,2,2)
%plot(Ry10i)
Ry20=xcorr(y20,'biased');
%subplot(2,2,3)
%plot(Ry20s)
%Ry20i=xcorr(y20,'unbiased');
%subplot(2,2,4)
%plot(Ry20i)
%Ry10s(1000)
%Ry10i(1000)
%Ry20i(1000)
%Ry20s(1000)

%punto 4
Sy10=abs(fft(Ry10));
Sy20=abs(fft(Ry20));
%K=linspace(-pi,pi,2*N-1);%falta poner entre -pi y pi
%subplot(2,1,1)
%plot(K,Sy10)
%subplot(2,1,2)
%plot(K,Sy20)

