N=1000;
W=randn(1,N);
impX = [1,-1];
X=filter(impX,1,W);
Rx=xcorr(X,'biased');
Sx=shift(abs(fft(Rx)),999);

impY = [1/2, 0, -1/2];
Y=filter(impY,1,W);
Ry=xcorr(Y,'biased');
Sy=shift(abs(fft(Ry)),999);

