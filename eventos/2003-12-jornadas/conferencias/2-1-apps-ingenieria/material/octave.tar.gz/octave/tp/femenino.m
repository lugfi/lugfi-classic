#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

## *************** ##
## **--** A **--** ##
## *************** ##



# Valores de frecuencia y ancho de banda **
F  = [ 0    850 1600 3050 4000 4800 5900 ];  # Frecuencia Pico
Bw = [ 1000 130 70   160  250  200  1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
A = vocales(F,Bw,Fs,d4); # d3 es la entrada elegida para la A

# Grabaci�n del sonido
ausave("a-fem.wav", A, Fs, "short");


## *************** ##
## **--** E **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    490 2500 3080 4060 4800 5900 ];  # Frecuencia Pico
Bw = [ 1000 100 60   110  250  200  1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
E = vocales(F,Bw,Fs,d3); # d3 es la entrada elegida para la E

# Grabaci�n del sonido
ausave("e-fem.wav", E, Fs, "short");


## *************** ##
## **--** I **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    240 2760 3600 4120 4800 5900 ];  # Frecuencia Pico
Bw = [ 1000 45  200   400  250  200 1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
I = vocales(F,Bw,Fs,d); # d es la entrada elegida para la I

# Grabaci�n del sonido
ausave("i-fem.wav", I, Fs, "short");


## *************** ##
## **--** O **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    480 960 2960 3860 4800 5900 ];  # Frecuencia Pico
Bw = [ 1000 80  70   70   250  200 1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
O = vocales(F,Bw,Fs,d5); # d5 es la entrada elegida para la O

# Grabaci�n del sonido
ausave("o-fem.wav", O, Fs, "short");


## *************** ##
## **--** U **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    280 720 2060 3940 4800 5900 ];  # Frecuencia Pico
Bw = [ 1000 50  55  100  250  200  1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
U = vocales(F,Bw,Fs,d6); # d6 es la entrada elegida para la U

# Grabaci�n del sonido
ausave("u-fem.wav", U, Fs, "short");

