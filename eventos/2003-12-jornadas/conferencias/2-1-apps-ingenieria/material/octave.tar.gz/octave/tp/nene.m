#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

# Definiciones generales
source "general-fem.m"
# Generacion de los fonemas
source "femenino.m"

# Nasales
source "nasales.m"
# Generaci�n de la N
source "ene.m"

# Generaci�n de un sonido conjunto para todas las vocales.
nene = [ 0.3*N; 
         E(1:length(E)/2); 
		 0.3*N; 
		 0.8*E(1:length(E)/3);];
ausave("nene.wav", nene, Fs, "short");

