#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

# Definiciones generales
source "general-fem.m"
# Generacion de los fonemas
source "femenino.m"

# Nasales
source "nasales.m"
# Generaci�n de la M
source "eme.m"
# Generaci�n de la N
source "ene.m"

# Generaci�n de un sonido conjunto para todas las vocales.
mano = [ 0.3*M(1:2*length(M)/5); 
         0.8*A(1:length(A)/2); 
		 0.2*N(1:2*length(N)/3); 
		 O(1:length(O)/3);];
ausave("mano.wav", mano, Fs, "short");

