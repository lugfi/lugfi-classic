#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

## *************** ##
## **--** N **--** ##
## *************** ##


# Valores de frecuencia y ancho de banda **
F  = [ 0    200 1200 2100 2960 ];  # Frecuencia Pico
Bw = [ 1000 150  80   50   50  ];  # Ancho de banda del pico.

# La entrada es una delta, pero partida en dos.
n=length(d);

# Funci�n general para filtrar.
N1 = nasales(F,Bw,Fs,d(1:1*n/20)); 

F  = [ 0    240 2200 3000 4040 ];  # Frecuencia Pico
N2 = nasales(F,Bw,Fs,d(1*n/20+1:5*n/10)); 

F  = [ 0    200 1800 2960 4000 ];  # Frecuencia Pico
N3 = nasales(F,Bw,Fs,d(5*n/20+1:7*n/20)); 

# Concatenaci�n
N = [ N1; N2; N3 ];

# Grabaci�n del sonido
ausave("n.wav", N, Fs, "short");

