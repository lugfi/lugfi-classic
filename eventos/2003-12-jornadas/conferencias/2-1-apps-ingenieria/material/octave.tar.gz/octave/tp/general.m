#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

# Inicio - Limpieza General
clear;

#
# Variables generales para todas las vocales
#
Fs = 16000;             # Frecuencia de Muestreo
Pitch = 100;            # Frecuencia Gl�tica
#Pitch = 160;            # Frecuencia Gl�tica Alternativa
#Pitch = 200;            # Frecuencia Gl�tica Alternativa
Per = Fs / Pitch;       # Per�odo del tren de deltas
Dur = 300;              # Milisegundos de duracion
N = (Dur / 1000) * Fs;  # Cantidad total de muestras

# Construcci�n de diversos trenes de deltas para entrada
for n=0:Per:N-Per,
	# Ruido
	r = 0.2*(rand()-0.5);
	# Los puntos con valor
    d(n+1) = 1 + r;                           # Constante
    d2(n+1) = sin(pi*n/N) + r;                # Medio periodo
    d3(n+1) = 1 - n/(3*N) + r;                # Levemente descendiente
    d4(n+1) = sin(pi*n/(2*N) + pi/4) + r;     # Un cuarto de periodo
    d5(n+1) = sin(3*pi*n/(5*N) + pi/5) + r;   # Un quinto de periodo
    d6(n+1) = 5/6 + n/(6*N) + r;              # Levemente ascendiente

	# Los puntos en cero
    d  = [d; zeros(Per-1,1)];
    d2 = [d2; zeros(Per-1,1)];
    d3 = [d3; zeros(Per-1,1)];
    d4 = [d4; zeros(Per-1,1)];
    d5 = [d5; zeros(Per-1,1)];
    d6 = [d6; zeros(Per-1,1)];
	
end

# Funci�n para filtrar las vocales.
# Recibe:
#  * un vector de frecuencias pico 
#  * un vector de anchos de banda.
#  * la frecuencia de muestreo.
#  * una entrada para alimentar al primer filtro.
# Devuelve la salida del �ltimo filtro.
#
function y = vocales(F,Bw,Fs,y)

	# Filtros de segundo orden, en cascada.
	for k=1:length(F),

	   # Coeficientes de la ecuaci�n en diferencias.
	   A1 = 2*e^(-pi*Bw(k)/Fs) * cos (2*pi*F(k)/Fs);
	   A2 = -e^(-2*pi*Bw(k)/Fs);
	   B  = 1 - A1 - A2;

	   # Filtro de segundo orden. 
	   y = filter([ B ], [1 -A1 -A2], y);
	end

	# Filtro para agregar nasalidad.  Modificado.
	y = filter([1 0.7], [1], y);

	# Filtro de segundo orden para agregar nasalidad.
	Bw = 6000; F = 1500;
	A1 = 2*e^(-pi*Bw/Fs) * cos (2*pi*F/Fs);
	A2 = -e^(-2*pi*Bw/Fs);
	B  = 1 - A1 - A2;
	y = filter([1 -A1 -A2], [B], y);

	# Normalizaci�n entre [-1 y 1]
	y = y/max(abs(y));

endfunction

