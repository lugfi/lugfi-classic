#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

## *************** ##
## **--** A **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    700 1220 2600 3300 3750 4900 ];  # Frecuencia Pico
Bw = [ 1000 130 70   160  250  200  1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
A = vocales(F,Bw,Fs,d4); # d4 es la entrada elegida para la A

# Grabaci�n del sonido
ausave("a.wav", A, Fs, "short");


## *************** ##
## **--** E **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    450 1800 2500 3300 3750 4900 ];  # Frecuencia Pico
Bw = [ 1000 100 60   110  250  200  1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
E = vocales(F,Bw,Fs,d3); # d3 es la entrada elegida para la E

# Grabaci�n del sonido
ausave("e.wav", E, Fs, "short");


## *************** ##
## **--** I **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    310 2020 2960 3300 3750 4900 ];  # Frecuencia Pico
Bw = [ 1000 45  200   400  250  200 1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
I = vocales(F,Bw,Fs,d); # d es la entrada elegida para la I

# Grabaci�n del sonido
ausave("i.wav", I, Fs, "short");


## *************** ##
## **--** O **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    470 1100 2400 3300 3750 4900 ];  # Frecuencia Pico
Bw = [ 1000 80  70   70   250  200  1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
O = vocales(F,Bw,Fs,d5); # d5 es la entrada elegida para la O

# Grabaci�n del sonido
ausave("o.wav", O, Fs, "short");


## *************** ##
## **--** U **--** ##
## *************** ##

# Valores de frecuencia y ancho de banda **
F  = [ 0    300 870 2240 3300 3750 4900 ];  # Frecuencia Pico
Bw = [ 1000 50  55  100  250  200  1000 ];  # Ancho de banda del pico.

# Funci�n general para filtrar.
U = vocales(F,Bw,Fs,d6); # d6 es la entrada elegida para la U

# Grabaci�n del sonido
ausave("u.wav", U, Fs, "short");

