#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

# Funci�n para filtrar las nasales.
# Recibe:
#  * un vector de frecuencias pico 
#  * un vector de anchos de banda.
#  * la frecuencia de muestreo.
#  * una entrada para alimentar al primer filtro.
# Devuelve la salida del �ltimo filtro.
#
function y = nasales(F,Bw,Fs,y)

	# Filtros de segundo orden, en cascada.
	for k=1:length(F),

	   # Coeficientes de la ecuaci�n en diferencias.
	   A1 = 2*e^(-pi*Bw(k)/Fs) * cos (2*pi*F(k)/Fs);
	   A2 = -e^(-2*pi*Bw(k)/Fs);
	   B  = 1 - A1 - A2;

	   # Filtro de segundo orden. 
	   y = filter([ B ], [1 -A1 -A2], y);
	end

	# Filtro para agregar nasalidad.  Modificado.
	y = filter([1 1.5], [1], y);

	# Filtro de segundo orden para agregar nasalidad.
	Bw = 6000; F = 1500;
	A1 = 2*e^(-pi*Bw/Fs) * cos (2*pi*F/Fs);
	A2 = -e^(-2*pi*Bw/Fs);
	B  = 1 - A1 - A2;
	y = filter([1 -A1 -A2], [B], y);

	# Normalizaci�n entre [-1 y 1]
	y = y/max(abs(y));

endfunction

