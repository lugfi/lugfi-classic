#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

# Definiciones generales
source "general-fem.m"
# Generacion de los fonemas
source "femenino.m"

# Generaci�n de un sonido conjunto para todas las vocales.
aeiou = [
         A(1:N-3*Per); 
		 0.4*A(N-3*Per+1:N) + 0.4*E(1:3*Per);
         0.7*E(3*Per+1:N-3*Per); 
		 0.4*E(N-3*Per+1:N) + 0.3*I(1:3*Per);
		 0.5*I(3*Per+1:N-3*Per); 
		 0.4*I(N-3*Per+1:N) + 0.4*O(1:3*Per);
		 O(3*Per+1:N-3*Per); 
		 0.5*O(N-3*Per+1:N) + 0.4*U(1:3*Per);
		 0.7*U(3*Per+1:N)];
ausave("aeiou-fem.wav", aeiou, Fs, "short");
