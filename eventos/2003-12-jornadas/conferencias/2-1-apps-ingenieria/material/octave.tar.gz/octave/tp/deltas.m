title " Una posible se�al de entrada ";
xlabel ("Tiempo (ms)");
ylabel ("Amplitud");
axis ("autoy"); axis("normal");
t=0:1000/Fs:300-1000/Fs;
plot (t,d3, "^;;");
print("images/delta-ruido.eps");
	  

