#!/usr/bin/octave

# ---------------------------------
# Copyleft Margarita Manterola 2003
# ---------------------------------

## *************** ##
## **--** M **--** ##
## *************** ##


# Valores de frecuencia y ancho de banda **
F  = [ 0    200 1200 2100 3900 4800 5900 ];  # Frecuencia Pico
Bw = [ 1000 130 70   160  250  200  1000 ];  # Ancho de banda del pico.

# La entrada es una delta, pero partida en dos.
n=length(d);

# Funci�n general para filtrar.
M1 = nasales(F,Bw,Fs,d(1:n/10)); 

F  = [ 0    200 1200 2900 3900 4800 5900 ];  # Frecuencia Pico
M2 = nasales(F,Bw,Fs,d(n/10+1:3*n/8)); 

# Concatenaci�n
M = [ M1; M2 ];

# Grabaci�n del sonido
ausave("m.wav", M, Fs, "short");

