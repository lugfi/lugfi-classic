#
# Ejemplo gen�rico de la utilizaci�n de filtros de segundo orden.
#

Fs = 8000;  # Frecuencia de Muestreo

function [h,w] = ztransf(F, Bw, Fs)
	A1 = 2*e^(-pi*Bw/Fs) * cos (2*pi*F/Fs);
	A2 = -e^(-2*pi*Bw/Fs);
	B = 1 - A1 - A2;
    [h, w] = freqz([B 0 0],[1 -A1 -A2]);
	w = w * Fs/(2*pi);
endfunction

function polosyceros(F, Bw, Fs)
	A1 = 2*e^(-pi*Bw/Fs) * cos (2*pi*F/Fs);
	A2 = -e^(-2*pi*Bw/Fs);
	B = 1 - A1 - A2;
#	t=0:0.1:2*pi;
#	x=cos(t);
#	y=sin(t);
#	plot(x,y); hold on;
	P = roots([1 -A1 -A2])
#	N = length(P);
#	for k = 1:N,
#		plot(1,0.5,'bx'); hold on;
#
#		plot(real(P[k]),imag(P[k])); hold;
#	end
#	figure()
    zplane([B 0 0],[1 -A1 -A2]);
endfunction

function s = menu_graficos(Fs)

  opc = menu("\nAn�lisis en el plano Z\nSeleccione una opci�n:", 
         "Polos y Ceros para F=700 y Bw=130", 
         "Polos y Ceros para F=1200 y Bw=70", 
         "Polos y Ceros para F=2600 y Bw=160", 
		 "Respuesta en Frecuencia para F=700 y Bw=130", 
		 "Respuesta en Frecuencia para F=1200 y Bw=70", 
		 "Respuesta en Frecuencia para F=2600 y Bw=160", 
         "Salir");
  s = 0;
  switch opc
    case (1)  
      # Diagrama de polos y ceros
	  figure();
	  title "    Diagrama de Polos y Ceros para F=700 y Bw=130";
	  xlabel(""); ylabel("");
	  polosyceros(700,130, Fs)
	  axis("equal"); grid("on");
	  print("images/polos700.eps");
    case (2)  
      # Diagrama de polos y ceros
	  figure();
	  title "    Diagrama de Polos y Ceros para F=1200 y Bw=70";
	  xlabel(""); ylabel("");
	  polosyceros(1200,70, Fs)
	  axis("equal"); grid("on");
	  print("images/polos1200.eps");
    case (3)  
      # Diagrama de polos y ceros
	  figure();
	  title "    Diagrama de Polos y Ceros para F=2600 y Bw=160";
	  xlabel(""); ylabel("");
	  polosyceros(2600,160, Fs)
	  axis("equal"); grid("on");
	  print("images/polos2600.eps");

    case(4)
      # Respuesta en frecuencia
      [h,w] = ztransf(700, 130, Fs);
      
	  # Gr�fico de la banda de corte
	  figure();
	  title "Respuesta en frecuencia para F=700 y Bw=130";
      axis ("label"); xlabel ("Frecuencia (Hz)"); ylabel("H (dB)");
      grid ("on"); gset lmargin 10;

      axis ("autoy"); axis("normal");
      axis ([ w(1), w(length(w))]);
      mag = 20 * log10 (abs (h));

      plot (w, mag, ";;");
	  print("images/freq700.eps", "-deps");

	case(5)
      # Respuesta en frecuencia
      [h,w] = ztransf(1200, 70, Fs);
  
	  # Gr�fico de la banda de corte
	  figure();
	  title "Respuesta en frecuencia para F=1200 y Bw=70";
      axis ("label"); xlabel ("Frecuencia (Hz)"); ylabel("H (dB)");
      grid ("on"); gset lmargin 10;

      axis ("autoy"); axis("normal");
      axis ([ w(1), w(length(w))]);
      mag = 20 * log10 (abs (h));

      plot (w, mag, ";;");
	  print("images/freq1200.eps", "-deps");
	  
	case(6)
      # Respuesta en frecuencia
      [h,w] = ztransf(2600, 160, Fs);
      
	  # Gr�fico de la banda de corte
	  figure();
	  title "Respuesta en frecuencia para F=2600 y Bw=160";
      axis ("label"); xlabel ("Frecuencia (Hz)"); ylabel("H (dB)");
      grid ("on"); gset lmargin 10;

      axis ("autoy"); axis("normal");
      axis ([ w(1), w(length(w))]);
      mag = 20 * log10 (abs (h));

      plot (w, mag, ";;");
	  print("images/freq2600.eps", "-deps");

	# Salida
    case(7)
	  s = 1;
  endswitch

endfunction

do
  s = menu_graficos(Fs);
until (s == 1);

